import os


def main():
    while True:
        print('Press 1 to Signup')
        print('Press 2 to Login')
        print('Press 0 to Exit')

        inp = input('Choice: ')

        if inp == '0':
            break
        elif inp == '1':
            id = input('Please enter your name: ')
            username = input('Please enter your Username: ')
            password = input('Please enter your Password: ')

            if os.path.exists('credentials.txt'):
                with open('credentials.txt', 'a') as f:
                    f.write(id + ':' + username + ':' + password + '\n')
            else:
                with open('credentials.txt', 'w') as f:
                    f.write(id + ':' + username + ':' + password + '\n')

            print('Signup Successful')
        elif inp == '2':
            if os.path.exists('credentials.txt'):
                username = input('Username: ')
                password = input('Password: ')

                with open('credentials.txt', 'r') as f:
                    flag = False
                    for line in f.readlines():
                        t = line.split(':')

                        if t[1].strip() == username and t[2].strip(
                        ) == password:
                            print('Login Successful')
                            print('Welcome ' + t[0] + '!!!')
                            flag = True
                            break

                    if not flag:
                        print('Username or Password is incorrect')
            else:
                print('No users in system')

        else:
            print('Invalid Option')


if __name__ == '__main__':
    main()
